--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `admin_id` int(10) UNSIGNED NOT NULL,
  `admin_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`admin_id`, `admin_email`, `admin_password`, `admin_name`, `admin_phone`, `created_at`, `updated_at`) VALUES
(1, 'aditya12@cse.pstu.ac.bd', 'e10adc3949ba59abbe56e057f20f883e', 'Aditya chakma', '01828915553', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category_tbl`
--

CREATE TABLE `category_tbl` (
  `category_id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` int(2) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_tbl`
--

INSERT INTO `category_tbl` (`category_id`, `category_name`, `category_description`, `publication_status`, `created_at`, `updated_at`) VALUES
(8, 'Men', 'This is men category....sg', 1, NULL, NULL),
(9, 'Women', 'This is for women', 1, NULL, NULL),
(10, 'Child', 'This is child category', 1, NULL, NULL),
(11, 'Electronics', 'This is electronics category', 1, NULL, NULL),
(12, 'Others', 'This is others category', 1, NULL, NULL),
(13, 'Furniture', 'This is furniture category', 1, NULL, NULL),
(14, 'Sports', 'This is sports category', 1, NULL, NULL),
(15, 'Laptop', 'This is laptop category', 1, NULL, NULL),
(16, 'Cloths', 'This is cloths category', 1, NULL, NULL),
(17, 'Computer', 'its computer category', 1, NULL, NULL),
(19, 'sports', 'its a sports product''s category.', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(10) UNSIGNED NOT NULL,
  `contact_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `contact_name`, `contact_image`, `contact_phone`, `contact_address`, `contact_city`, `contact_email`, `created_at`, `updated_at`) VALUES
(7, 'Aditya Chakma', 'public/contact/pMbuW.jpg', '01828915553', 'Rangamati,Chittagong', 'Rangamati', 'aditya12@cse.pstu.ac.bd', NULL, NULL),
(8, 'Mohammad Ali', 'public/contact/If0Yp.jpg', '01521200494', 'Jashore,Khulna', 'Jashore', 'destructive17ali@gmail.com', NULL, NULL),
(9, 'Juan L. Long', 'public/contact/jh5y5.png', '4062503700', '52 Woodland Dr.  Brooklyn, NY 11203', 'New York', 'JuanLLong@jourrapide.com', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `manufacture_tbl`
--

CREATE TABLE `manufacture_tbl` (
  `manufacture_id` int(10) UNSIGNED NOT NULL,
  `manufacture_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `manufacture_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `manufacture_tbl`
--

INSERT INTO `manufacture_tbl` (`manufacture_id`, `manufacture_name`, `manufacture_description`, `publication_status`, `created_at`, `updated_at`) VALUES
(1, 'Samsung', 'this is samsung brand', 1, NULL, NULL),
(2, 'Zara', 'zara pants', 1, NULL, NULL),
(3, 'Otobi', 'otobi brand', 1, NULL, NULL),
(4, 'addidas', 'addidas brand', 1, NULL, NULL),
(5, 'Chillor rose', 'women''s brand', 1, NULL, NULL),
(8, 'Lara', 'Lara pants', 1, NULL, NULL),
(10, 'HUAWEI', 'This is huawei mobile brand...', 1, NULL, NULL),
(11, 'Symphony', 'Symphony is a mobile brand&nbsp;', 1, NULL, NULL),
(12, 'Xiaomi', 'This is xiaomi mobile brand', 1, NULL, NULL),
(13, 'Walton', 'This is walton brand', 1, NULL, NULL),
(14, 'Oppo', 'This is oppo brand', 1, NULL, NULL),
(15, 'Nokia', 'This is nokia brand', 1, NULL, NULL),
(16, 'HTC', 'this is HTC brand', 1, NULL, NULL),
(17, 'OnePlus', 'This is oneplus mobile brand', 1, NULL, NULL),
(18, 'HP', 'this hp laptop brand', 1, NULL, NULL),
(19, 'ASUS', 'this asus laptop brand', 1, NULL, NULL),
(20, 'DELL', 'this is dell computer brand', 1, NULL, NULL),
(21, 'Lenovo', 'this is lenovo computer brand', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_07_18_171809_create_admin_tbl_table', 1),
(2, '2018_07_22_164942_create_category_tbl_table', 2),
(3, '2018_07_25_080233_create_manufacture_tbl_table', 3),
(4, '2018_10_10_191134_create_tbl_products_table', 4),
(5, '2018_10_13_093409_create_tbl_slider_table', 5),
(6, '2018_10_16_113011_create_tbl_customer_table', 6),
(7, '2018_10_16_191920_create_tbl_shipping_table', 7),
(8, '2018_10_17_153545_create_tbl_payment_table', 8),
(9, '2018_10_17_153650_create_tbl_order_table', 8),
(10, '2018_10_17_153802_create_tbl_order_details_table', 8),
(11, '2018_10_18_094849_create_tbl_payment_table', 9),
(12, '2018_10_18_095034_create_tbl_order_table', 9),
(13, '2018_10_18_095157_create_tbl_order_details_table', 9),
(14, '2019_01_13_072516_create_contacts_table', 10),
(15, '2019_01_28_151028_create_suppliers_table', 11);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `suppliers_id` int(10) UNSIGNED NOT NULL,
  `suppliers_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `suppliers_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `suppliers_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `suppliers_adderss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `suppliers_city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `suppliers_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`suppliers_id`, `suppliers_name`, `suppliers_image`, `suppliers_phone`, `suppliers_adderss`, `suppliers_city`, `suppliers_email`, `created_at`, `updated_at`) VALUES
(1, 'Abdullah Al Noman', 'public/suppliers/HHmfZ.jpg', '0182891773', 'Barisal', 'Patuakhali', 'noman@gmail.com', NULL, NULL),
(3, 'Musa Ahmed', 'public/suppliers/gwXc8.png', '01828916665', 'Khulna', 'Khulna', 'MusaAhmed@gmail.com', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `customer_id` int(10) UNSIGNED NOT NULL,
  `customer_first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`customer_id`, `customer_first_name`, `customer_last_name`, `customer_email`, `password`, `phone_number`, `created_at`, `updated_at`) VALUES
(15, 'aditya', 'chakma', 'aditya@gmail.com', '057829fa5a65fc1ace408f490be486ac', '01828915553', NULL, NULL),
(16, 'aditya', 'Chakma', 'adi@gmail.com', 'e807f1fcf82d132f9bb018ca6738a19f', '4234234', NULL, NULL),
(17, 'aditya', 'chakz', 'adityachakz@gmail.com', '014401a20cfcb23bf82954c9516429eb', '01828915553', NULL, NULL),
(18, 'Rudro Pratap', 'Aditya', 'aditya12@cse.pstu.ac.bd', '25f9e794323b453885f5181f1b624d0b', '4235213634626', NULL, NULL),
(19, 'aditya', 'chakma', 'aditya1996@gmail.com', '057829fa5a65fc1ace408f490be486ac', '01828915553', NULL, NULL),
(20, 'rudro', 'aditya', 'aditya12@cse.pstu.ac.bd', '057829fa5a65fc1ace408f490be486ac', '4062503700', NULL, NULL),
(21, 'Bhugol', 'Bijoy', 'bhugol@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '4346363462523', NULL, NULL),
(22, 'bugol', 'bijoy', 'bugol@cse.gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '35235252456346', NULL, NULL),
(23, 'taher', 'kaku', 'taher@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, NULL),
(24, 'Maloti', 'Chakma', 'maloti@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '25375757898', NULL, NULL),
(25, 'Aditya laxmi', 'chakma', 'adi1234@gmail.com', '65d744e91930b8c1875570ea27d11aea', '7956473642466', NULL, NULL),
(26, 'Ali Ahmed', 'Jessore', 'aliahemed@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '12345678', NULL, NULL),
(27, 'Margan', 'Hoassain', 'margan@gmail.com', 'baab8982359da5d0d711ec1114ae9f2c', '12345678', NULL, NULL),
(28, 'Mirza fakrul', 'Islam', 'islam@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '352362624624', NULL, NULL),
(29, 'fsdfsdj', 'fsfgbdfbdf', 'dhgd@gmail.com', 'c58db98053d460c006c0d77d83fc04ca', '5364746537', NULL, NULL),
(30, 'fsgsgfhn', '2343245', '45365@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, NULL),
(31, 'Musabbir', 'Rahman', 'musa12@gmail.com', '23e6d6d83450496ed8e3018729cc2738', '264346357457', NULL, NULL),
(32, 'Maloti Chakma', 'Prova', 'prova@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '01882228027', NULL, NULL),
(33, 'thtr', 'htrh', 'adfete@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '4y65524314', NULL, NULL),
(34, 'dhrhge', 'rgerg', 'rgerg@gmail.com', 'f9af11cccf3b22004942fee5a84f62d7', '756473562', NULL, NULL),
(35, 'fdtgh', 'thrth', 'dfad@gmail.com', '3465ccbb4e995fcb2f0ac28ebbd27eb9', 'g3erge', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `order_id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(11) NOT NULL,
  `shipping_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `order_total` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `customer_id`, `shipping_id`, `payment_id`, `order_total`, `order_status`, `created_at`, `updated_at`) VALUES
(10, 15, 27, 12, '149,790.00', '1', '2018-10-18 12:08:58', NULL),
(11, 15, 27, 13, '94,900.00', '1', '2018-10-18 12:41:43', NULL),
(12, 15, 28, 14, '284,700.00', '0', '2018-10-24 08:44:08', NULL),
(13, 15, 29, 15, '4,321.00', '0', '2018-10-24 09:25:34', NULL),
(14, 18, 30, 16, '60,000.00', '0', '2018-10-24 09:28:46', NULL),
(15, 15, 31, 17, '73,800.00', '0', '2018-10-24 18:16:30', NULL),
(16, 19, 32, 18, '53,970.00', '0', '2018-10-25 10:38:02', NULL),
(17, 20, 33, 19, '25,980.00', '1', '2018-10-29 11:37:14', NULL),
(18, 21, 34, 20, '189,800.00', '1', '2018-11-13 17:05:54', NULL),
(19, 22, 35, 21, '36,900.00', '1', '2018-11-13 17:09:05', NULL),
(20, 23, 36, 22, '189,800.00', '1', '2018-12-02 13:07:54', NULL),
(21, 24, 37, 23, '295,200.00', '1', '2018-12-18 13:56:09', NULL),
(22, 25, 38, 24, '33,953.00', '1', '2019-01-12 14:11:03', NULL),
(23, 26, 39, 25, '8,999.00', '1', '2019-01-12 15:27:52', NULL),
(24, 27, 40, 26, '31,980.00', '1', '2019-01-12 20:46:53', NULL),
(25, 27, 40, 27, '31,980.00', '1', '2019-01-12 21:22:32', NULL),
(26, 29, 42, 28, '189,800.00', '1', '2019-01-13 09:09:01', NULL),
(27, 30, 43, 29, '94,900.00', '1', '2019-01-26 18:33:55', NULL),
(28, 31, 44, 30, '94,900.00', '1', '2019-01-27 06:17:52', NULL),
(29, 32, 45, 31, '94,900.00', '1', '2019-01-28 22:43:58', NULL),
(32, 32, 47, 34, '94,900.00', 'pending', '2019-01-29 11:10:48', NULL),
(33, 32, 48, 35, '94,900.00', 'pending', '2019-01-29 12:11:28', NULL),
(36, 32, 50, 38, '94,900.00', 'pending', '2019-01-29 12:20:23', NULL),
(37, 32, 51, 39, '27,990.00', 'pending', '2019-01-29 13:15:59', NULL),
(38, 32, 52, 40, '35,980.00', '1', '2019-01-30 18:53:11', NULL),
(39, 32, 54, 41, '4,234.00', 'pending', '2019-02-03 13:57:20', NULL),
(40, 32, 55, 42, '12,500.00', 'pending', '2019-02-03 14:00:38', NULL),
(41, 32, 55, 43, '12,500.00', 'pending', '2019-02-03 14:00:46', NULL),
(42, 32, 55, 44, '0.00', 'pending', '2019-02-03 14:00:56', NULL),
(43, 32, 55, 45, '0.00', 'pending', '2019-02-03 14:01:01', NULL),
(44, 32, 56, 46, '159,790.00', 'pending', '2019-02-05 16:16:34', NULL),
(45, 32, 58, 47, '94,900.00', '1', '2019-02-11 11:09:42', NULL),
(46, 32, 59, 48, '12,990.00', '1', '2019-02-18 15:47:08', NULL),
(47, 32, 59, 49, '9,990.00', '1', '2019-02-18 15:51:46', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_details`
--

CREATE TABLE `tbl_order_details` (
  `order_details_id` int(10) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_sales_quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_order_details`
--

INSERT INTO `tbl_order_details` (`order_details_id`, `order_id`, `product_id`, `product_name`, `product_price`, `product_sales_quantity`, `created_at`, `updated_at`) VALUES
(1, 1, 8, 'Samsung Galaxy Note 9', '94900', '1', NULL, NULL),
(2, 1, 11, 'Samsung Galaxy A6+', '36900', '3', NULL, NULL),
(3, 2, 8, 'Samsung Galaxy Note 9', '94900', '1', NULL, NULL),
(4, 2, 11, 'Samsung Galaxy A6+', '36900', '3', NULL, NULL),
(5, 3, 12, 'Samsung Galaxy J4', '12990', '1', '2018-10-18 11:33:38', NULL),
(6, 4, 12, 'Samsung Galaxy J4', '12990', '1', '2018-10-18 11:58:39', NULL),
(7, 8, 8, 'Samsung Galaxy Note 9', '94900', '1', '2018-10-18 12:00:17', NULL),
(8, 10, 8, 'Samsung Galaxy Note 9', '94900', '1', '2018-10-18 12:08:58', NULL),
(9, 11, 8, 'Samsung Galaxy Note 9', '94900', '1', '2018-10-18 12:41:43', NULL),
(10, 12, 8, 'Samsung Galaxy Note 9', '94900', '3', '2018-10-24 08:44:08', NULL),
(11, 13, 14, 'Ladies frock', '4321', '1', '2018-10-24 09:25:34', NULL),
(12, 14, 15, 'Ladies frock', '60000', '1', '2018-10-24 09:28:46', NULL),
(13, 15, 11, 'Samsung Galaxy A6+', '36900', '2', '2018-10-24 18:16:30', NULL),
(14, 16, 13, 'Samsung Galaxy J6', '17990', '3', '2018-10-25 10:38:02', NULL),
(15, 17, 12, 'Samsung Galaxy J4', '12990', '2', '2018-10-29 11:37:14', NULL),
(16, 18, 8, 'Samsung Galaxy Note 9', '94900', '2', '2018-11-13 17:05:54', NULL),
(17, 19, 11, 'Samsung Galaxy A6+', '36900', '1', '2018-11-13 17:09:06', NULL),
(18, 20, 8, 'Samsung Galaxy Note 9', '94900', '2', '2018-12-02 13:07:54', NULL),
(19, 21, 11, 'Samsung Galaxy A6+', '36900', '8', '2018-12-18 13:56:09', NULL),
(20, 22, 14, 'Ladies frock', '4321', '3', '2019-01-12 14:11:03', NULL),
(21, 23, 41, 'Symphony i75', '8999', '1', '2019-01-12 15:27:52', NULL),
(22, 24, 33, 'Huawei Y7 Pro (2018)', '15990', '2', '2019-01-12 20:46:53', NULL),
(23, 25, 33, 'Huawei Y7 Pro (2018)', '15990', '2', '2019-01-12 21:22:32', NULL),
(24, 26, 8, 'Samsung Galaxy Note 9', '94900', '2', '2019-01-13 09:09:01', NULL),
(25, 27, 8, 'Samsung Galaxy Note 9', '94900', '1', '2019-01-26 18:33:55', NULL),
(26, 28, 8, 'Samsung Galaxy Note 9', '94900', '1', '2019-01-27 06:17:52', NULL),
(27, 29, 8, 'Samsung Galaxy Note 9', '94900', '1', '2019-01-28 22:43:58', NULL),
(28, 30, 16, 'Ladies frock', '32435', '1', '2019-01-29 09:13:41', NULL),
(29, 32, 8, 'Samsung Galaxy Note 9', '94900', '1', '2019-01-29 11:10:48', NULL),
(30, 33, 8, 'Samsung Galaxy Note 9', '94900', '1', '2019-01-29 12:11:28', NULL),
(31, 36, 8, 'Samsung Galaxy Note 9', '94900', '1', '2019-01-29 12:20:24', NULL),
(32, 37, 9, 'Samsung Galaxy J8', '27990', '1', '2019-01-29 13:15:59', NULL),
(33, 38, 13, 'Samsung Galaxy J6', '17990', '2', '2019-01-30 18:53:11', NULL),
(34, 39, 27, 'Men''s jeans', '4234', '1', '2019-02-03 13:57:20', NULL),
(35, 40, 47, 'Oppo A71 (2018)', '12500', '1', '2019-02-03 14:00:38', NULL),
(36, 41, 47, 'Oppo A71 (2018)', '12500', '1', '2019-02-03 14:00:46', NULL),
(37, 44, 8, 'Samsung Galaxy Note 9', '94900', '1', '2019-02-05 16:16:34', NULL),
(38, 45, 8, 'Samsung Galaxy Note 9', '94900', '1', '2019-02-11 11:09:42', NULL),
(39, 46, 12, 'Samsung Galaxy J4', '12990', '1', '2019-02-18 15:47:08', NULL),
(40, 47, 38, 'Symphony i120', '9990', '1', '2019-02-18 15:51:46', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `payment_id` int(10) UNSIGNED NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`payment_id`, `payment_method`, `payment_status`, `created_at`, `updated_at`) VALUES
(1, 'handcash', 'pending', '2018-10-18 11:28:21', NULL),
(2, 'handcash', 'pending', '2018-10-18 11:29:47', NULL),
(3, 'handcash', 'pending', '2018-10-18 11:30:37', NULL),
(4, 'card', 'pending', '2018-10-18 11:30:54', NULL),
(5, 'card', 'pending', '2018-10-18 11:33:38', NULL),
(6, 'handcash', 'pending', '2018-10-18 11:58:39', NULL),
(7, 'handcash', 'pending', '2018-10-18 11:59:11', NULL),
(8, 'handcash', 'pending', '2018-10-18 11:59:15', NULL),
(9, 'handcash', 'pending', '2018-10-18 11:59:19', NULL),
(10, 'handcash', 'pending', '2018-10-18 12:00:17', NULL),
(11, 'handcash', 'pending', '2018-10-18 12:01:07', NULL),
(12, 'handcash', 'pending', '2018-10-18 12:08:58', NULL),
(13, 'handcash', 'pending', '2018-10-18 12:41:43', NULL),
(14, 'handcash', 'pending', '2018-10-24 08:44:08', NULL),
(15, 'handcash', 'pending', '2018-10-24 09:25:34', NULL),
(16, 'handcash', 'pending', '2018-10-24 09:28:46', NULL),
(17, 'handcash', 'pending', '2018-10-24 18:16:30', NULL),
(18, 'handcash', 'pending', '2018-10-25 10:38:02', NULL),
(19, 'handcash', 'pending', '2018-10-29 11:37:14', NULL),
(20, 'handcash', 'pending', '2018-11-13 17:05:54', NULL),
(21, 'handcash', 'pending', '2018-11-13 17:09:05', NULL),
(22, 'handcash', 'pending', '2018-12-02 13:07:54', NULL),
(23, 'handcash', 'pending', '2018-12-18 13:56:09', NULL),
(24, 'handcash', 'pending', '2019-01-12 14:11:03', NULL),
(25, 'handcash', 'pending', '2019-01-12 15:27:51', NULL),
(26, 'card', 'pending', '2019-01-12 20:46:53', NULL),
(27, 'card', 'pending', '2019-01-12 21:22:32', NULL),
(28, 'handcash', 'pending', '2019-01-13 09:09:01', NULL),
(29, 'handcash', 'pending', '2019-01-26 18:33:55', NULL),
(30, 'handcash', 'pending', '2019-01-27 06:17:52', NULL),
(31, 'handcash', 'pending', '2019-01-28 22:43:58', NULL),
(32, 'handcash', 'pending', '2019-01-29 09:13:41', NULL),
(33, 'handcash', 'pending', '2019-01-29 09:21:42', NULL),
(34, 'handcash', 'pending', '2019-01-29 11:10:48', NULL),
(35, 'handcash', 'pending', '2019-01-29 12:11:27', NULL),
(36, 'handcash', 'pending', '2019-01-29 12:11:53', NULL),
(37, 'handcash', 'pending', '2019-01-29 12:12:26', NULL),
(38, 'handcash', 'pending', '2019-01-29 12:20:23', NULL),
(39, 'handcash', 'pending', '2019-01-29 13:15:59', NULL),
(40, 'handcash', 'pending', '2019-01-30 18:53:11', NULL),
(41, 'handcash', 'pending', '2019-02-03 13:57:20', NULL),
(42, 'paypal', 'pending', '2019-02-03 14:00:38', NULL),
(43, 'handcash', 'pending', '2019-02-03 14:00:46', NULL),
(44, 'card', 'pending', '2019-02-03 14:00:56', NULL),
(45, 'handcash', 'pending', '2019-02-03 14:01:01', NULL),
(46, 'handcash', 'pending', '2019-02-05 16:16:34', NULL),
(47, 'handcash', 'pending', '2019-02-11 11:09:42', NULL),
(48, 'handcash', 'pending', '2019-02-18 15:47:07', NULL),
(49, 'handcash', 'pending', '2019-02-18 15:51:46', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

CREATE TABLE `tbl_products` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `product_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `manufacture_id` int(11) NOT NULL,
  `product_short_description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_long_description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` double(8,2) NOT NULL,
  `product_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_products`
--

INSERT INTO `tbl_products` (`product_id`, `product_name`, `category_id`, `manufacture_id`, `product_short_description`, `product_long_description`, `product_price`, `product_image`, `product_size`, `product_color`, `publication_status`, `created_at`, `updated_at`) VALUES
(8, 'Samsung Galaxy Note 9', 11, 1, 'ddghsdgjsdjksdjfsdgjkcdh', 'sdfsdfsfsdfsdff', 94900.00, 'image/POeGdi5i6L2SCgRh3uOT.jpg', '161.9 x 76.4 x 8.8 millimeter, 201 grams (Gorilla Glass 5 on front and back, aluminum frame)', 'Metallic copper, Lavender purple, Ocean blue, Midnight black', 0, NULL, NULL),
(9, 'Samsung Galaxy J8', 11, 1, '<span style="color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: rgb(243, 243, 243);">Lithium-ion 3500 mAh (non-removable)</span><br style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px;"><span style="color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: rgb(243, 243, 243);">Talk-time: -</span>', '<span style="color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: rgb(243, 243, 243);">16 MP - (Autofocus, f/1.7 aperture)</span><br style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px;"><span style="color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: rgb(243, 243, 243);">5 MP - (f/1.9 aperture, depth sensor)</span><br style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px;"><span style="color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: rgb(243, 243, 243);">LED flash, auto face detection, HDR, panorama mode</span>', 27990.00, 'image/LmGlsk9gl5VS8IYvXQYZ.jpg', '6.0 inches, HD+ 720 x 1480 pixels (293 ppi)', 'Black, Gold, Blue', 0, NULL, NULL),
(11, 'Samsung Galaxy A6+', 11, 1, 'it is good', 'it is a good product', 36900.00, 'image/4asYiAFCXq8S6BC02Gz1.jpg', '6.0 inches, Full HD+ 1080 x 2220 pixels (411 ppi)', 'Black, Gold, Blue, Lavender', 0, NULL, NULL),
(12, 'Samsung Galaxy J4', 11, 1, '<span style="color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: rgb(243, 243, 243);">Lithium-ion 3000 mAh (removable)</span><br style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px;"><span style="color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: rgb(243, 243, 243);">Stand-by time: -</span><br style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px;"><span style="color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: rgb(243, 243, 243);">Talk-time: up to 20 hours (3G)</span>', '<span style="color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: rgb(243, 243, 243);">- Bluetooth, GPS, A-GPS, MP3, MP4, Radio, RDS, GPRS, Edge, Multitouch, HTML</span>', 12990.00, 'image/hMGSJK0CyUeNY7NQLBHM.jpg', '5.5 inches, HD 720 x 1280 pixels', 'Black, Gold, Orchid Gray', 0, NULL, NULL),
(13, 'Samsung Galaxy J6', 11, 1, '<span style="color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: rgb(243, 243, 243);">Lithium-ion 3000 mAh (non-removable)</span><br style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px;"><span style="color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: rgb(243, 243, 243);">Talk-time: up tp 21 hours (3G)cccccc</span><br style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px;"><span style="color: rgb(86, 100, 111); font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: rgb(243, 243, 243);">Stand-by time: -</span>', '<table id="tablepress-1554" class="tablepress tablepress-id-1554" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px 0px 1em; padding: 0px; border: none; outline: 0px; font-size: 13px; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; border-collapse: collapse; border-spacing: 0px; width: 710px; max-width: 100%; color: rgb(86, 100, 111); background-color: rgb(255, 255, 255);"><tbody class="row-hover" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 0px; border: 0px; outline: 0px; font-weight: inherit; font-style: inherit; font-family: inherit; vertical-align: baseline;"><tr class="row-4 even" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 0px; border-width: 0px 0px 1px; border-top-style: initial; border-right-style: initial; border-bottom-style: solid; border-left-style: initial; border-top-color: initial; border-right-color: initial; border-bottom-color: rgb(234, 234, 234); border-left-color: initial; border-image: initial; outline: 0px; font-weight: inherit; font-style: inherit; font-family: inherit; vertical-align: baseline; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><td class="column-1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 8px; border-top: 1px solid rgb(221, 221, 221); border-right: none; border-bottom: none; border-left: none; border-image: initial; outline: 0px; vertical-align: top; font-variant-numeric: normal; font-variant-east-asian: normal; line-height: inherit; overflow-wrap: break-word; background-image: initial; background-position: 0px 0px; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; float: none !important;">Body &amp; Weight</td><td class="column-2" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 8px; border-top: 1px solid rgb(221, 221, 221); border-right: none; border-bottom: none; border-left: none; border-image: initial; outline: 0px; vertical-align: top; font-variant-numeric: normal; font-variant-east-asian: normal; line-height: inherit; overflow-wrap: break-word; background-image: initial; background-position: 0px 0px; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; float: none !important;">149.3 x 70.2 x 8.2 millimeter, 154 grams (Plastic Unibody)</td></tr><tr class="row-5 odd" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 0px; border-width: 0px 0px 1px; border-top-style: initial; border-right-style: initial; border-bottom-style: solid; border-left-style: initial; border-top-color: initial; border-right-color: initial; border-bottom-color: rgb(234, 234, 234); border-left-color: initial; border-image: initial; outline: 0px; font-weight: inherit; font-style: inherit; font-family: inherit; vertical-align: baseline; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><td class="column-1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 8px; border-top: 1px solid rgb(221, 221, 221); border-right: none; border-bottom: none; border-left: none; border-image: initial; outline: 0px; vertical-align: top; font-variant-numeric: normal; font-variant-east-asian: normal; line-height: inherit; overflow-wrap: break-word; background: 0px 0px rgb(249, 249, 249); float: none !important;">Camera Factors (Back)</td><td class="column-2" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 8px; border-top: 1px solid rgb(221, 221, 221); border-right: none; border-bottom: none; border-left: none; border-image: initial; outline: 0px; vertical-align: top; font-variant-numeric: normal; font-variant-east-asian: normal; line-height: inherit; overflow-wrap: break-word; background: 0px 0px rgb(249, 249, 249); float: none !important;">F/1.9, 28mm, autofocus, LED flash, auto face detection, HDR, panorama mode</td></tr><tr class="row-6 even" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 0px; border-width: 0px 0px 1px; border-top-style: initial; border-right-style: initial; border-bottom-style: solid; border-left-style: initial; border-top-color: initial; border-right-color: initial; border-bottom-color: rgb(234, 234, 234); border-left-color: initial; border-image: initial; outline: 0px; font-weight: inherit; font-style: inherit; font-family: inherit; vertical-align: baseline; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><td class="column-1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 8px; border-top: 1px solid rgb(221, 221, 221); border-right: none; border-bottom: none; border-left: none; border-image: initial; outline: 0px; vertical-align: top; font-variant-numeric: normal; font-variant-east-asian: normal; line-height: inherit; overflow-wrap: break-word; background-image: initial; background-position: 0px 0px; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; float: none !important;">Camera Resolution (Back)</td><td class="column-2" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 8px; border-top: 1px solid rgb(221, 221, 221); border-right: none; border-bottom: none; border-left: none; border-image: initial; outline: 0px; vertical-align: top; font-variant-numeric: normal; font-variant-east-asian: normal; line-height: inherit; overflow-wrap: break-word; background-image: initial; background-position: 0px 0px; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; float: none !important;">13 Megapixel</td></tr><tr class="row-7 odd" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 0px; border-width: 0px 0px 1px; border-top-style: initial; border-right-style: initial; border-bottom-style: solid; border-left-style: initial; border-top-color: initial; border-right-color: initial; border-bottom-color: rgb(234, 234, 234); border-left-color: initial; border-image: initial; outline: 0px; font-weight: inherit; font-style: inherit; font-family: inherit; vertical-align: baseline; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><td class="column-1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 8px; border-top: 1px solid rgb(221, 221, 221); border-right: none; border-bottom: none; border-left: none; border-image: initial; outline: 0px; vertical-align: top; font-variant-numeric: normal; font-variant-east-asian: normal; line-height: inherit; overflow-wrap: break-word; background: 0px 0px rgb(249, 249, 249); float: none !important;">Camera Resolution (Front)</td><td class="column-2" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 8px; border-top: 1px solid rgb(221, 221, 221); border-right: none; border-bottom: none; border-left: none; border-image: initial; outline: 0px; vertical-align: top; font-variant-numeric: normal; font-variant-east-asian: normal; line-height: inherit; overflow-wrap: break-word; background: 0px 0px rgb(249, 249, 249); float: none !important;">8 Megapixel (F/1.9 aperture, LED flash)</td></tr><tr class="row-8 even" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 0px; border-width: 0px 0px 1px; border-top-style: initial; border-right-style: initial; border-bottom-style: solid; border-left-style: initial; border-top-color: initial; border-right-color: initial; border-bottom-color: rgb(234, 234, 234); border-left-color: initial; border-image: initial; outline: 0px; font-weight: inherit; font-style: inherit; font-family: inherit; vertical-align: baseline; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><td class="column-1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 8px; border-top: 1px solid rgb(221, 221, 221); border-right: none; border-bottom: none; border-left: none; border-image: initial; outline: 0px; vertical-align: top; font-variant-numeric: normal; font-variant-east-asian: normal; line-height: inherit; overflow-wrap: break-word; background: 0px 0px rgb(243, 243, 243); float: none !important;">Chipset</td><td class="column-2" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px; padding: 8px; border-top: 1px solid rgb(221, 221, 221); border-right: none; border-bottom: none; border-left: none; border-image: initial; outline: 0px; vertical-align: top; font-variant-numeric: normal; font-variant-east-asian: normal; line-height: inherit; overflow-wrap: break-word; background: 0px 0px rgb(243, 243, 243); float: none !important;">Exynos 7870 Octa</td></tr></tbody></table>', 17990.00, 'image/jaHC6Og8YpQ82aeBIXcM.jpg', '5.6 inches, HD+ 720 x 1480 pixels', 'Black, Gold, Blue', 1, NULL, NULL),
(14, 'Ladies frock', 9, 2, 'gdg', 'gfdg', 4321.00, 'image/u0vWFkVagFO52Vu240r5.jpg', '3213', 'fsffdgfg', 1, NULL, NULL),
(15, 'Ladies frock', 9, 2, 'gergegwe', 'fwefewfew', 7000.00, 'image/15.jpg', '53454', 'gedgedfg', 0, NULL, NULL),
(16, 'Ladies frock', 9, 2, 'htdrhrth', 'trherheh', 32435.00, 'image/u1eyZmwuYgkcRTZHkJ6h.jpg', 'gergrre', 'grreg', 1, NULL, NULL),
(17, 'Ladies frock', 9, 2, 'retret43t4', 'tretretrtr', 43243.00, 'image/9ac80AGgk1RPwO1LbVpm.jpeg', 'ghrghfdgd', 'dsfgvdfg', 1, NULL, NULL),
(18, 'Ladies frock', 9, 2, 'ggergwefw', 'retgregreg', 9000.00, 'image/18.jpeg', 'tretert', 'retret', 1, NULL, NULL),
(19, 'Ladies frock', 9, 2, 'tryertret', 'tretretret', 534543.00, 'image/ypgLElDLcoR7TAtYdBqa.jpg', 'ertgretgre', 'gregg', 1, NULL, NULL),
(20, 'Ladies frock', 9, 2, 'gbfdgfdgh', 'gdfggb', 53453.00, 'image/iiQTo9cYVn81HaOMJDfA.jpg', 'tretgretr3', 'tr3trt', 1, NULL, NULL),
(21, 'Babies shoes', 10, 4, 'retretgretgretgr', 'gretgregyr', 543543.00, 'image/sKEDVZXEZLSDxeQWOd5g.jpg', 'fewfwe', 'wefewf', 1, NULL, NULL),
(22, 'Babies shoes', 10, 4, 'gberg', 'gfdgdfgd', 2000.00, 'image/22.jpg', 'yt4tygte', 'tgertert', 1, NULL, NULL),
(23, 'Babies shoes', 10, 4, 'gerggerg', 'ergergrgreg', 4343.00, 'image/yry08yeY0ZQe2tjl2sbO.jpg', 'grgghghd', 'rfwrwer', 1, NULL, NULL),
(24, 'Babies shoes', 10, 4, 'tgregregre', 'ergregreg', 234.00, 'image/oCZI2BOpFs55144IYA6l.jpg', 'gerg', 'dgdfg', 1, NULL, NULL),
(25, 'Babies shoes', 10, 4, 'gregregreggdgdg', 'gfdgf', 4321.00, 'image/CmvEl7O0vKE1RjVlQJ7l.jpg', 'ffwef', 'ewrfwe', 1, NULL, NULL),
(26, 'Babies shoes', 10, 4, 'gfdgdfgfdg', 'gdfgfdg', 2343.00, 'image/RQTGDGfE3KU7Mk86Rme3.jpg', 'wf', 'sfs', 1, NULL, NULL),
(27, 'Men''s jeans', 8, 5, 'dfgg', 'gdfgf', 4234.00, 'image/XF4VjPxKr2IvO8Nl1VJQ.jpg', '3433', 'errer', 1, NULL, NULL),
(28, 'Football', 14, 8, 'grgg', 'grege', 432.00, 'image/G5DVOe6WDVnfbGBcirhz.jpg', 'rfwer', 'rwerw', 1, NULL, NULL),
(29, 'Huawei Nova 3i', 11, 10, 'sfsdfsd', 'fsdfsdfdc', 28990.00, 'image/xXkvarKkfYugvv3hYNQo.jpg', '6.3 inches, Full HD+ 1080 x 2340 pixels (409 ppi)', 'Black, Pearl White, Iris Purple', 1, NULL, NULL),
(30, 'Huawei Y5 Prime (2018)', 11, 10, 'gdfb', 'cbcvbv', 11590.00, 'image/8yxmVq2nozns3jWCnPXb.jpg', '5.45 inches, HD+ 720 x 1440 pixels (295 ppi)', 'Black, Blue, Gold', 1, NULL, NULL),
(31, 'Huawei P20 Pro', 11, 10, 'dfgdfdfdf', 'hergdgd', 82990.00, 'image/sbC9JVQbfB8H6DExFDWT.jpg', '6.1 inches, Full HD 1080 x 2244 pixels (408 ppi)', 'Twilight, Black, Midnight Blue, Pink Gold', 1, NULL, NULL),
(32, 'Huawei Y3 2018', 11, 10, 'vfgbbfd', 'dfdv', 8890.00, 'image/kVTvTBqWJA7i0Xd271Y2.jpg', '5.0 inches, 480 x 854 pixels (196 ppi)', 'Gold, White, Gray', 1, NULL, NULL),
(33, 'Huawei Y7 Pro (2018)', 11, 10, 'gdgd', 'vdfvdf', 15990.00, 'image/XIQcsm2LRwTyPuxwleKY.jpg', '5.99 inches, HD+ 720 x 1440 pixels (269 ppi)', 'Black, Blue, Gold', 1, NULL, NULL),
(34, 'Huawei Y6 Prime (2018)', 11, 10, 'dbdfbd', 'bbbf', 13990.00, 'image/OAACNTCrja3phzctED5l.jpg', '5.7 inches, HD+ 720 x 1440 pixels', 'Black, Blue, Gold', 1, NULL, NULL),
(35, 'Huawei Nova 3e', 11, 10, 'bfgbdfb', 'dfbdfbdf', 27990.00, 'image/sQ35kQ3N0rVGfKtwSx8q.jpg', '5.84 inches, Full HD 1080 x 2244 pixels (432 ppi)', 'Midnight Black, Klein Blue, Sakura Pink, Platinum Gold', 1, NULL, NULL),
(37, 'Symphony G100', 11, 11, 'dfgdfgdfg', 'fgdfgdfgdf', 5999.00, 'image/9oqXNRSQCydlgt5WXv5d.jpg', '5.45 inches, FWVGA 854 x 480 pixels (197 ppi)', '-', 1, NULL, NULL),
(38, 'Symphony i120', 11, 11, 'bdfbdfbdf', 'bdfbdfbdfbd', 9990.00, 'image/jpnOU6YpgldQDCyHk11X.jpg', '5.45 inches, HD+ 720 × 1440 pixels (295 ppi)', 'Red Black, Blue Black, Gold', 1, NULL, NULL),
(39, 'Symphony i15', 11, 11, 'dfbfbfb', 'dfbdfbdfb', 6690.00, 'image/fPbLy2giF5yuveVFdmbd.jpg', '5.45 inches, HD+ 720 x 1440 pixels (296 ppi)', 'No official data', 1, NULL, NULL),
(40, 'Symphony V135', 11, 11, 'bgdfgdfgdf', 'vdffbdfb', 5690.00, 'image/0WyuJsV40Mt1VxdEzgwq.jpg', '5.34 inches, FWVGA+ 950 x 480 pixels (201 ppi) Display Type	Full-Vision Touchscreen', 'Golden', 1, NULL, NULL),
(41, 'Symphony i75', 11, 11, 'bfbfbdfb', 'bdfbdfb', 8999.00, 'image/vVNRlvliSPCuVp2dUwnH.jpg', '5.72 inches, HD+ 720 × 1280 pixels (281 ppi)', 'Black', 1, NULL, NULL),
(42, 'Symphony V96', 11, 11, 'nffgnfgnf', 'cnnvn fn', 4899.00, 'image/OCuOOcHJvXNYa2du4g7t.jpg', '5 inches, FWVGA 854 × 480 pixels (196 ppi)', 'Black', 1, NULL, NULL),
(43, 'Oppo A5', 11, 14, 'ngnfgnnfg', 'fgbvbnfgnfnf', 20990.00, 'image/yxUPIeaKkZ20zr8UCraE.jpg', '6.2 inches, HD+ 720 x 1520 pixels (271 ppi)', 'Diamond Blue, Diamond Red', 1, NULL, NULL),
(44, 'Oppo F9', 11, 14, 'nfgnfgnfgnfg', 'nfgnfgnfgn', 28990.00, 'image/OCNHI9pYKQnS6KhfXBab.jpg', '6.3 inches, Full HD+ 1080 x 2340 pixels (409 ppi)', 'Sunrise Red, Twilight Blue, Starry Purple', 1, NULL, NULL),
(45, 'Oppo A3s', 11, 14, 'bbfb', 'bdfdfd', 14990.00, 'image/hsbJOr3623nZaddFN23d.jpg', '6.2 inches, HD+ 720 x 1520 pixels (282 ppi)', 'Red, Dark Purple', 1, NULL, NULL),
(46, 'Oppo F7', 11, 14, 'bdfbdfbdf', 'bdfbdfbdfbdfbdfbdfbdf', 27990.00, 'image/shsKnGQM6wEnM4DQfgHD.jpg', '6.23 inches, Full HD+ 1080 x 2280 pixels (405 ppi)', 'Solar Red, Diamond Black, Moonlight Silver', 1, NULL, NULL),
(47, 'Oppo A71 (2018)', 11, 14, 'fhfhhgvkhggjgjgkjg', 'fhgkjgjgjkhkuhjh', 12500.00, 'image/u3M8LlCUxR84Gqe2FtZQ.jpg', '5.2 inches, HD 1280 x 720 pixels (282 ppi)', 'Gold, Black, Rose Gold', 1, NULL, NULL),
(48, 'Oppo A83 (2018)', 11, 14, 'gndjgfjffhfy', 'ggfujfygjgk', 13500.00, 'image/XYtfKICd6wGhm0uBNBcq.jpg', '5.7 inches, HD+ 720 x 1440 pixels (282 ppi)', 'Champagne, Black', 1, NULL, NULL),
(49, 'Oppo F5', 11, 14, 'hfhdfkhfkhfh', 'hvhmnvmmv', 24990.00, 'image/4CabC19TUxtMhukdUhID.jpg', '6.0 inches, Full HD+ 1080 x 2160 pixels (402 ppi)', 'Gold, Black, Red', 1, NULL, NULL),
(50, 'HTC U11', 11, 16, 'bv cv vvv&nbsp;&nbsp;', 'cnnghvvhdgdsdfghj', 66990.00, 'image/lpXBZ25oxJWCllpJ4Qjt.jpg', '5.5 inches, Quad HD 1440 x 2560 pixels, Dual Display pixel density (534 ppi)', 'Amazing Silver, Sapphire Blue, Brilliant Black, Ice White, Solar Red', 1, NULL, NULL),
(51, 'Samsung Galaxy A6 Smartphone 5.6', 11, 1, 'Samsung galaxy A6', 'Samsung galaxy A6', 27900.00, 'image/uPihjukTfG3pacazoowl.jpg', '5.6" HD+ Super AMOLED Display', 'Black, Gold, Blue, Lavender', 1, NULL, NULL),
(52, 'Samsung Galaxy A9', 11, 1, '<h2 style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px 0px 0px -0.05em; padding: 0.5em 0px; border: 0px; outline: 0px; vertical-align: baseline; text-rendering: optimizelegibility; line-height: 1.3em; background-color: rgb(255, 255, 255); text-align: center;"><font color="#333333" face="Arial, Helvetica, sans-serif"><span style="font-size: 21.3333px; letter-spacing: -0.426667px;">Samsung Galaxy A9 Full Specifications</span></font></h2>', '<font face="Arial, Verdana"><span style="font-size: 13.3333px;">Samsung Galaxy A9 Full Specifications</span></font>', 49900.00, 'image/52.jpg', '6.3 inches, Full HD+ 1080 x 2220 pixels (392 ppi) - 18.5:9 ratio Full-View Infinity Super AMOLED Touchscreen - Always-on Display', 'Caviar Black, Lemonade Blue, Bubblegum Pink', 1, NULL, NULL),
(53, 'Samsung Galaxy J6+', 11, 1, '<h2 style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px 0px 0px -0.05em; padding: 0.5em 0px; border: 0px; outline: 0px; font-weight: normal; font-size: 1.6em; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51); text-rendering: optimizelegibility; letter-spacing: -0.02em; line-height: 1.3em; background-color: rgb(255, 255, 255); text-align: center;"><b style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1);">Samsung Galaxy J6+ Full Specifications</b></h2>', '<h2 style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px 0px 0px -0.05em; padding: 0.5em 0px; border: 0px; outline: 0px; font-weight: normal; font-size: 1.6em; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51); text-rendering: optimizelegibility; letter-spacing: -0.02em; line-height: 1.3em; background-color: rgb(255, 255, 255); text-align: center;"><b style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1);">Samsung Galaxy J6+ Full Specifications</b></h2>', 16990.00, 'image/53.jpg', '6.0 inches, HD+ 720 x 1480 pixels - 18.5:9 ration Full-View Infinity TFT Touchscreen', 'Black, Blue, Red', 1, NULL, NULL),
(54, 'Samsung Galaxy A7 (2018)', 11, 1, '<h2 style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px 0px 0px -0.05em; padding: 0.5em 0px; border: 0px; outline: 0px; font-weight: normal; font-size: 1.6em; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51); text-rendering: optimizelegibility; letter-spacing: -0.02em; line-height: 1.3em; background-color: rgb(255, 255, 255); text-align: center;"><b style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1);">Samsung Galaxy A7 (2018) Full Specifications</b></h2>', '<h2 style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px 0px 0px -0.05em; padding: 0.5em 0px; border: 0px; outline: 0px; font-weight: normal; font-size: 1.6em; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51); text-rendering: optimizelegibility; letter-spacing: -0.02em; line-height: 1.3em; background-color: rgb(255, 255, 255); text-align: center;"><b style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1);">Samsung Galaxy A7 (2018) Full Specifications</b></h2>', 24990.00, 'image/54.jpg', '6.0 inches, Full HD+ 1080 x 2220 pixels (294 ppi) - Full-View Infinity Super AMOLED Touchscreen, Corning Gorilla Glass protection - Always-on Display', 'Black, blue, gold, pink', 1, NULL, NULL),
(55, 'Samsung Galaxy J2 Core', 11, 1, '<h2 style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px 0px 0px -0.05em; padding: 0.5em 0px; border: 0px; outline: 0px; font-weight: normal; font-size: 1.6em; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51); text-rendering: optimizelegibility; letter-spacing: -0.02em; line-height: 1.3em; background-color: rgb(255, 255, 255); text-align: center;"><b style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1);">Samsung Galaxy J2 Core</b></h2>', '<h2 style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px 0px 0px -0.05em; padding: 0.5em 0px; border: 0px; outline: 0px; font-weight: normal; font-size: 1.6em; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51); text-rendering: optimizelegibility; letter-spacing: -0.02em; line-height: 1.3em; background-color: rgb(255, 255, 255); text-align: center;"><b style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1);">Samsung Galaxy J2 Core</b></h2>', 8290.00, 'image/6Zy3nFwKliHzE4bCb8AI.jpg', '5.0 inches, qHD 540 x 960 pixels - Touchscreen, Corning Gorilla Glass protection', 'Black, Gold, Blue', 1, NULL, NULL),
(56, 'Samsung Galaxy Note 9', 11, 1, '<h1 class="entry-title post-title" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px auto 2px; padding: 5px 0px; border: 0px; outline: 0px; font-weight: normal; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51); text-rendering: optimizelegibility; letter-spacing: -0.04em; line-height: 1em; text-align: center; max-width: 700px; background-color: rgb(235, 235, 235);">Samsung Galaxy Note 9</h1>', '<h1 class="entry-title post-title" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px auto 2px; padding: 5px 0px; border: 0px; outline: 0px; font-weight: normal; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51); text-rendering: optimizelegibility; letter-spacing: -0.04em; line-height: 1em; text-align: center; max-width: 700px; background-color: rgb(235, 235, 235);">Samsung Galaxy Note 9</h1>', 94900.00, 'image/vLRmYA2JSMxFAuiYqSdm.jpg', '6.4 inches, qHD 1440 x 2960 pixels (516 ppi) - 18.5:9 ratio Full-View Super AMOLED Touchscreen, Corning Gorilla Glass 5 protection', 'Metallic copper, Lavender purple, Ocean blue, Midnight black', 1, NULL, NULL),
(57, 'Samsung Galaxy J8', 11, 1, '<h1 class="entry-title post-title" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px auto 2px; padding: 5px 0px; border: 0px; outline: 0px; font-weight: normal; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51); text-rendering: optimizelegibility; letter-spacing: -0.04em; line-height: 1em; text-align: center; max-width: 700px; background-color: rgb(235, 235, 235);">Samsung Galaxy J8</h1>', '<h1 class="entry-title post-title" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px auto 2px; padding: 5px 0px; border: 0px; outline: 0px; font-weight: normal; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51); text-rendering: optimizelegibility; letter-spacing: -0.04em; line-height: 1em; text-align: center; max-width: 700px; background-color: rgb(235, 235, 235);">Samsung Galaxy J8</h1>', 21990.00, 'image/QpQtcMJ3CXMcnHsqDC4I.jpg', '6.0 inches, HD+ 720 x 1480 pixels (293 ppi) - 18.5:9 ratio Full-View Infinity Super AMOLED Touchscreen', 'Black, Gold, Blue', 1, NULL, NULL),
(58, 'Samsung Galaxy A6', 11, 1, '<h1 class="entry-title post-title" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px auto 2px; padding: 5px 0px; border: 0px; outline: 0px; font-weight: normal; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51); text-rendering: optimizelegibility; letter-spacing: -0.04em; line-height: 1em; text-align: center; max-width: 700px; background-color: rgb(235, 235, 235);">Samsung Galaxy A6</h1>', '<h1 class="entry-title post-title" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px auto 2px; padding: 5px 0px; border: 0px; outline: 0px; font-weight: normal; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51); text-rendering: optimizelegibility; letter-spacing: -0.04em; line-height: 1em; text-align: center; max-width: 700px; background-color: rgb(235, 235, 235);">Samsung Galaxy A6</h1>', 27900.00, 'image/DKwDYtFuaeGKdUymLlGM.jpg', '5.6 inches, HD+ 720 x 1480 pixels (294 ppi) - Full-View Infinity Super AMOLED Touchscreen', 'Black, Gold, Blue, Lavender', 1, NULL, NULL),
(59, 'Samsung Galaxy J7 Pro', 11, 1, '<h2 style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px 0px 0px -0.05em; padding: 0.5em 0px; border: 0px; outline: 0px; font-weight: normal; font-size: 1.6em; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51); text-rendering: optimizelegibility; letter-spacing: -0.02em; line-height: 1.3em; background-color: rgb(255, 255, 255); text-align: center;"><b style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1);">Samsung Galaxy J7 Pro</b></h2>', '<h2 style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1); margin: 0px 0px 0px -0.05em; padding: 0.5em 0px; border: 0px; outline: 0px; font-weight: normal; font-size: 1.6em; font-family: Arial, Helvetica, sans-serif; vertical-align: baseline; color: rgb(51, 51, 51); text-rendering: optimizelegibility; letter-spacing: -0.02em; line-height: 1.3em; background-color: rgb(255, 255, 255); text-align: center;"><b style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1);">Samsung Galaxy J7 Pro</b></h2>', 29490.00, 'image/WZORSg5zOH867XSJSitf.jpg', '5.5 inches, Full HD 1080 x 1920 pixels (401 ppi) - Super AMOLED Touchscreen', 'Black, Gold', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shipping`
--

CREATE TABLE `tbl_shipping` (
  `shipping_id` int(10) UNSIGNED NOT NULL,
  `shipping_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_shipping`
--

INSERT INTO `tbl_shipping` (`shipping_id`, `shipping_email`, `shipping_first_name`, `shipping_last_name`, `shipping_address`, `shipping_phone_number`, `shipping_city`, `created_at`, `updated_at`) VALUES
(1, 'dgd@gmail.com', 'csdvsdv', 'vsdvsdv', 'svsv', '343w43', 'ggdfgdd', NULL, NULL),
(2, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(3, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(4, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(5, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(6, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(7, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(8, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(9, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(10, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(11, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(12, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(13, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(14, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(15, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(16, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(17, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(18, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(19, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(20, 'adityachakz@gmail.com', 'aditya', 'chakz', 'bangladesh', '01828915553', 'dhaka', NULL, NULL),
(21, 'fsdfsf@gmail.com', 'dwedwe', 'dfwf', 'sdf', 'wefwef', 'fwfw', NULL, NULL),
(22, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(23, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(24, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(25, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(26, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(27, 'adibabu@gmail.com', 'Aditya', 'Chakma', 'sdafgdfgad', '01828915553', 'Rangamati', NULL, NULL),
(28, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(29, 'adggg@gmail.com', 'laxmi', 'joy', 'sfegfer', 'ffefe', 'New erferf', NULL, NULL),
(30, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(31, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(32, 'adityachakma1996@gmail.com', 'aditya', 'Chakma', 'dhaka', '01828915553', 'mirpur', NULL, NULL),
(33, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(34, 'bhugol@gmail.com', 'bhugol', 'bijoy', 'sggdhsgsrh', 'xhhhgfg345434757475', 'fjdgjtyjtj', NULL, NULL),
(35, 'A@gmail.com', 'bugol', 'bijouy', 'htrhstrhrhr', '36463y3', 'bfsrr', NULL, NULL),
(36, 'fsdfsf@gmail.com', 'dwedwe', 'dfwf', 'sdf', 'wefwef', 'fwfw', NULL, NULL),
(37, 'maloti@gmail.com', 'maloti', 'chakma', 'Chittagong,Rangamati', '74538565876969', 'sgdfhdhfd', NULL, NULL),
(38, 'adi1234@gmail.com', 'aditya', 'chakma', '16 Jhigatola Rd, Dhaka 1205, Bangladesh', '346247456', '16 Jhigatola Rd', NULL, NULL),
(39, 'ALiahemed@gmail.com', 'ali', 'ahmed', 'dhaka', '123456789', 'mirpur', NULL, NULL),
(40, 'margan@gmail.com', 'Margan', 'Hossain', 'Sylet', '01828915553', 'Sylet', NULL, NULL),
(41, 'asfshs@gmail.com', 'asfsdg', 'sdgsdg', 'dsgfd', '254355', 'fbdgn', NULL, NULL),
(42, 'fdhfgn@gmail.com', 'Fahim', 'Chakma', 'sgfnnd', '574535747', 'nfgnffn', NULL, NULL),
(43, 'aditya12647865656@cse.pstu.ac.bd', 'ADITYAgfhhvhjn', 'CHAKMA', '16 Jhigatola Rd, Dhaka 1205, Bangladesh', '537476587', '16 Jhigatola Rd', NULL, NULL),
(44, 'musa12@cse.pstu.ac.bd', 'musabbir', 'rahman', '16 Jhigatola Rd, Dhaka 1205, Bangladesh', '2352463463', '16 Jhigatola Rd', NULL, NULL),
(45, 'prova@gmail.com', 'maloti Chakma', 'Prova', 'Sapchori,rangamati', '01882228027', 'Rangamati', NULL, NULL),
(46, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(47, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(48, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(49, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(50, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(51, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(52, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(53, 'aditya12@cse.pstu.ac.bd', 'ADITYA', 'CHAKMA', '16 Jhigatola Rd, Dhaka 1205, Bangladesh', '235346346', '16 Jhigatola Rd', NULL, NULL),
(54, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(55, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(56, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(57, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(58, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL),
(59, 'JuanLLong@jourrapide.com', 'Juan', 'L. Long', '52 Woodland Dr.  Brooklyn, NY 11203', '4062503700', 'New York', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `slider_id` int(10) UNSIGNED NOT NULL,
  `slider_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`slider_id`, `slider_image`, `publication_status`, `created_at`, `updated_at`) VALUES
(2, 'slider/hVz78zpawoe08ebTiHLA.jpg', '0', NULL, NULL),
(4, 'slider/wAJgNpuiUnSROze06NAh.jpg', '0', NULL, NULL),
(5, 'slider/mjr79xDLS1JfQFkvym6H.jpg', '0', NULL, NULL),
(6, 'slider/hpyzPBg3TmTLvqYNYJDz.jpg', '0', NULL, NULL),
(8, 'slider/hW7UNcYb0G432x9zGAe4.jpg', '1', NULL, NULL),
(9, 'slider/sh5M5CvVUGpBhEjVC0wC.jpeg', '0', NULL, NULL),
(10, 'slider/U4YkzocmcVdZimEoC0EK.jpg', '1', NULL, NULL),
(11, 'slider/BPTDLg1EUZd7MgvCP7qN.jpg', '1', NULL, NULL),
(13, 'slider/aKBvAMKoXq5DoizJxjEg.jpg', '0', NULL, NULL),
(14, 'slider/5x5IstwlWBITyOi6yXfo.jpg', '0', NULL, NULL),
(15, 'slider/kd6au3LMCKHdyhkZUYMX.jpg', '0', NULL, NULL),
(16, 'slider/uXkIGJ0aZ4itNd2hbsAF.png', '0', NULL, NULL),
(17, 'slider/dtjj29J1tpbwBwGUBZ6Q.jpg', '1', NULL, NULL),
(18, 'slider/UQLvyo72vvPrjfToI2lG.jpg', '1', NULL, NULL),
(19, 'slider/fjHNcENFCHIZC4q5XUgk.jpg', '1', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `category_tbl`
--
ALTER TABLE `category_tbl`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manufacture_tbl`
--
ALTER TABLE `manufacture_tbl`
  ADD PRIMARY KEY (`manufacture_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`suppliers_id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  ADD PRIMARY KEY (`order_details_id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `tbl_products`
--
ALTER TABLE `tbl_products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  ADD PRIMARY KEY (`shipping_id`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`slider_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `admin_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `category_tbl`
--
ALTER TABLE `category_tbl`
  MODIFY `category_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `manufacture_tbl`
--
ALTER TABLE `manufacture_tbl`
  MODIFY `manufacture_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `suppliers_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `customer_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `order_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  MODIFY `order_details_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `payment_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `tbl_products`
--
ALTER TABLE `tbl_products`
  MODIFY `product_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  MODIFY `shipping_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `slider_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
